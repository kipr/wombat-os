var structkipr_1_1create_1_1CreatePackets_1_1__3 =
[
    [ "batteryCapacity", "structkipr_1_1create_1_1CreatePackets_1_1__3.html#aa77d7747ceda73f3a6d771d14fe59533", null ],
    [ "batteryCharge", "structkipr_1_1create_1_1CreatePackets_1_1__3.html#a8b36484d8da13bdc1622dcd5f0065fa5", null ],
    [ "batteryTemperature", "structkipr_1_1create_1_1CreatePackets_1_1__3.html#a3ed52006b07963fc36d43fb76b9bea52", null ],
    [ "chargingState", "structkipr_1_1create_1_1CreatePackets_1_1__3.html#a5e2b2b8c731ddbd789dc65c53714336d", null ],
    [ "current", "structkipr_1_1create_1_1CreatePackets_1_1__3.html#abca6b88153db86ee454cd2c9ed249200", null ],
    [ "voltage", "structkipr_1_1create_1_1CreatePackets_1_1__3.html#ad9531c510a0ecf3fbeaca49ebe74c100", null ]
];
var structkipr_create3_client_AudioNote =
[
    [ "frequency", "structkipr_create3_client_AudioNote.html#a4feece2ec58d909444613177ec67e2bc", null ],
    [ "seconds", "structkipr_create3_client_AudioNote.html#ac537f5c6afbda6ef42cc428540058ecb", null ],
];
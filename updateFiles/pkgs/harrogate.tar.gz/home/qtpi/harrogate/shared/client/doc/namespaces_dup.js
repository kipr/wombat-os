var namespaces_dup =
[
    [ "cv", "namespacecv.html", null ],
    [ "kipr", "namespacekipr.html", "namespacekipr" ],
    [ "std", "namespacestd.html", "namespacestd" ]
];
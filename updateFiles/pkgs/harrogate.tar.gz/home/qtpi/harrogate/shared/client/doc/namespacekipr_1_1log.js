var namespacekipr_1_1log =
[
    [ "Flush", "structkipr_1_1log_1_1Flush.html", null ],
    [ "Location", "structkipr_1_1log_1_1Location.html", "structkipr_1_1log_1_1Location" ],
    [ "LogStream", "classkipr_1_1log_1_1LogStream.html", "classkipr_1_1log_1_1LogStream" ],
    [ "Log", "classkipr_1_1log_1_1Log.html", "classkipr_1_1log_1_1Log" ],
    [ "Level", "namespacekipr_1_1log.html#ac448d0ee86b50f80a44a11636d65fe34", [
      [ "Fatal", "namespacekipr_1_1log.html#ac448d0ee86b50f80a44a11636d65fe34a882384ec38ce8d9582b57e70861730e4", null ],
      [ "Error", "namespacekipr_1_1log.html#ac448d0ee86b50f80a44a11636d65fe34a902b0d55fddef6f8d651fe1035b7d4bd", null ],
      [ "Warning", "namespacekipr_1_1log.html#ac448d0ee86b50f80a44a11636d65fe34a0eaadb4fcb48a0a0ed7bc9868be9fbaa", null ],
      [ "Info", "namespacekipr_1_1log.html#ac448d0ee86b50f80a44a11636d65fe34a4059b0251f66a18cb56f544728796875", null ],
      [ "Debug", "namespacekipr_1_1log.html#ac448d0ee86b50f80a44a11636d65fe34aa603905470e2a5b8c13e96b579ef0dba", null ],
      [ "Verbose", "namespacekipr_1_1log.html#ac448d0ee86b50f80a44a11636d65fe34ad4a9fa383ab700c5bdd6f31cf7df0faf", null ]
    ] ],
    [ "flush", "namespacekipr_1_1log.html#a41f43a60fb94700f7372818de9255aa4", null ]
];
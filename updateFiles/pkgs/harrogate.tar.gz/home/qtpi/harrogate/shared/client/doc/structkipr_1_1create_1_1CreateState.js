var structkipr_1_1create_1_1CreateState =
[
    [ "angle", "structkipr_1_1create_1_1CreateState.html#a9e7d902602de78237b4c57ed30f2473a", null ],
    [ "distance", "structkipr_1_1create_1_1CreateState.html#abf7892ddcaebc78a04e40590c008b97a", null ],
    [ "leftVelocity", "structkipr_1_1create_1_1CreateState.html#adace48d28610a2d9d2637b5b48527554", null ],
    [ "radius", "structkipr_1_1create_1_1CreateState.html#afac9f5cf0c8ff835c2588f1ba6ad4304", null ],
    [ "rightVelocity", "structkipr_1_1create_1_1CreateState.html#a0da2624fe399f3753bf235776253c2e0", null ],
    [ "timestamp", "structkipr_1_1create_1_1CreateState.html#aff5312accc3d37fb3c142810d0c24692", null ]
];
var class_magneto_x =
[
    [ "value", "class_magneto_x.html#a4d0ee00761231b3b41fc453b133ab116", null ]
];
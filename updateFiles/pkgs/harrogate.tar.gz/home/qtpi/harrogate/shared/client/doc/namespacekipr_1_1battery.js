var namespacekipr_1_1battery =
[
    [ "Battery", "classkipr_1_1battery_1_1Battery.html", null ]
];
var namespacekipr_1_1sensor =
[
    [ "logic", "namespacekipr_1_1sensor_1_1logic.html", "namespacekipr_1_1sensor_1_1logic" ],
    [ "Sensor", "classkipr_1_1sensor_1_1Sensor.html", "classkipr_1_1sensor_1_1Sensor" ]
];
var namespacekipr_1_1config =
[
    [ "Config", "classkipr_1_1config_1_1Config.html", "classkipr_1_1config_1_1Config" ]
];
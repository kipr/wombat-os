var classkipr_1_1magneto_1_1MagnetoZ =
[
    [ "value", "classkipr_1_1magneto_1_1MagnetoZ.html#ab518164867a9f2e086ab2d1fdc746224", null ]
];
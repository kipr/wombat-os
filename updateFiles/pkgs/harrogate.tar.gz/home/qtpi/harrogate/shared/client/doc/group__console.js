var group__console =
[
    [ "Console", "classkipr_1_1console_1_1Console.html", null ],
    [ "", "group__console.html", null ],
    [ "console_clear", "group__console.html#ga490370bb141fb9d46cafb20abdf77e65", null ]
];
var classAddress =
[
    [ "Address", "classAddress.html#a48f07460b0e2f9c3363b15a4575f1246", null ],
    [ "Address", "classAddress.html#a7112bb43b003883514eebd942f3c88c5", null ],
    [ "Address", "classAddress.html#a63f910c09d93bdd16d3744e47d13dc0e", null ],
    [ "addr", "classAddress.html#a73558a7cf6c850ef548788f0bfa44131", null ],
    [ "addrLength", "classAddress.html#aa83a507a64bd8f7a7e3e8cb376b2e8d1", null ],
    [ "ip", "classAddress.html#aa081ca5bf0c19c6a9ef851e370009471", null ],
    [ "isValid", "classAddress.html#a854eed86c57d012930069daa8ec5d5b1", null ],
    [ "port", "classAddress.html#afcba3f4a73addfc2262b549ae62e7c8f", null ],
    [ "setHost", "classAddress.html#a46d0a5cd67550608d49e422bad632d09", null ],
    [ "setPort", "classAddress.html#a7c3715175945e8e1f7ff16e92ed0f85c", null ]
];
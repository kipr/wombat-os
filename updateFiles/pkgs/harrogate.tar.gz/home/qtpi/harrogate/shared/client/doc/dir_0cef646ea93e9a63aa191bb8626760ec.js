var dir_0cef646ea93e9a63aa191bb8626760ec =
[
    [ "magneto.h", "magneto_8h.html", "magneto_8h" ],
    [ "magneto.hpp", "magneto_8hpp.html", [
      [ "Magneto", "classkipr_1_1magneto_1_1Magneto.html", null ],
      [ "MagnetoX", "classkipr_1_1magneto_1_1MagnetoX.html", "classkipr_1_1magneto_1_1MagnetoX" ],
      [ "MagnetoY", "classkipr_1_1magneto_1_1MagnetoY.html", "classkipr_1_1magneto_1_1MagnetoY" ],
      [ "MagnetoZ", "classkipr_1_1magneto_1_1MagnetoZ.html", "classkipr_1_1magneto_1_1MagnetoZ" ]
    ] ]
];
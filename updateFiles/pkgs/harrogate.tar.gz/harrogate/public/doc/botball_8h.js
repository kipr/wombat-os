var botball_8h =
[
    [ "shut_down_in", "botball_8h.html#ae558f9e5e2bcaa84384565dadd03f89c", null ],
    [ "wait_for_light", "botball_8h.html#accee163b76004358fc63decc3b1579fe", null ]
];
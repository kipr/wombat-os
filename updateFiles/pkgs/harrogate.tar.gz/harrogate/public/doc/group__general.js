var group__general =
[
    [ "publish", "group__general.html#ga2955f8e823ea99f92d32a86f21a5dab2", null ],
    [ "set_auto_publish", "group__general.html#ga038517d3df8f236dde8eefbbcadee37e", null ]
];
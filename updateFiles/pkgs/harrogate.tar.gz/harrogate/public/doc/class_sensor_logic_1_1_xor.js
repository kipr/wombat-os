var class_sensor_logic_1_1_xor =
[
    [ "Xor", "class_sensor_logic_1_1_xor.html#a5f7e090069e78974b0f64f8fa289f4a5", null ],
    [ "value", "class_sensor_logic_1_1_xor.html#a4369b73e49d1af23539f753f96793c3c", null ]
];
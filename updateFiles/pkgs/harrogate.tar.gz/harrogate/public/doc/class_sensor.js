var class_sensor =
[
    [ "~Sensor", "class_sensor.html#a33f614626c02a1c7bc9529fd7b7b9888", null ],
    [ "value", "class_sensor.html#ae6f85150fdf64adc35531424f537db0f", null ]
];
var structpoint2 =
[
    [ "x", "structpoint2.html#a945025c0035751bfc726251dda81da54", null ],
    [ "y", "structpoint2.html#a4caabf9c28bb6b0283b028ddad9c8a62", null ]
];
var class_sensor_logic_1_1_and =
[
    [ "And", "class_sensor_logic_1_1_and.html#a3bd2dead87e7ac1e4aa0dd5aaa4cb272", null ],
    [ "value", "class_sensor_logic_1_1_and.html#a13a9d00976aba766713effec1673fe8a", null ]
];
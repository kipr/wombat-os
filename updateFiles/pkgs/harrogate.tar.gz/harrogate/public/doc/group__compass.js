var group__compass =
[
    [ "calibrate_compass", "group__compass.html#ga967556bd100e24df918e7adb912bd26a", null ],
    [ "get_compass_angle", "group__compass.html#ga1514178173bb3ea8effe4d6c183ec0f9", null ],
    [ "set_compass_params", "group__compass.html#gac3e85c6216882ab5e6cc0be3111bc2c7", null ]
];
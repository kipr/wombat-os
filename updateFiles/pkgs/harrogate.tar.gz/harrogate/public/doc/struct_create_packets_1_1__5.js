var struct_create_packets_1_1__5 =
[
    [ "leftVelocity", "struct_create_packets_1_1__5.html#a526562678506eeb39c98b0f931f82070", null ],
    [ "mode", "struct_create_packets_1_1__5.html#a8e0aa367e92d1f71fb5529aebc0524fe", null ],
    [ "numberOfStreamPackets", "struct_create_packets_1_1__5.html#a4a0d48a6888139c2cc95684d347da98a", null ],
    [ "radius", "struct_create_packets_1_1__5.html#ad1a1b8cea63738f865e1a73b2273ded0", null ],
    [ "rightVelocity", "struct_create_packets_1_1__5.html#a7eebb61e1b704aec9ee486c835577ee0", null ],
    [ "songNumber", "struct_create_packets_1_1__5.html#a38cf07521363824d3e827e3f9764c7d8", null ],
    [ "songPlaying", "struct_create_packets_1_1__5.html#a8160c3d84c485baa109d4b6418f7aad6", null ],
    [ "velocity", "struct_create_packets_1_1__5.html#a2ef6c68b60c096b2cdfc712b25ddc97f", null ]
];
var struct_create_packets_1_1__2 =
[
    [ "angle", "struct_create_packets_1_1__2.html#a425d33bd27790066ff7edb4a608a8149", null ],
    [ "buttons", "struct_create_packets_1_1__2.html#a6b7d2d6c0a3a063f873420c010063b33", null ],
    [ "distance", "struct_create_packets_1_1__2.html#afb30de28ec41190d0cb278640d4782ab", null ],
    [ "ir", "struct_create_packets_1_1__2.html#ac834057741105e898b3d4613b96c6eb1", null ]
];
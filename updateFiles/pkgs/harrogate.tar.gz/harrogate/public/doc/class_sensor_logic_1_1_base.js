var class_sensor_logic_1_1_base =
[
    [ "Base", "class_sensor_logic_1_1_base.html#a3f00f9d42dc170865af9d69ca26e66fb", null ],
    [ "~Base", "class_sensor_logic_1_1_base.html#a97a4c5de864b01b69c05337a6f7933fb", null ],
    [ "a", "class_sensor_logic_1_1_base.html#af02311e65650eba25db49ad790487ab9", null ],
    [ "b", "class_sensor_logic_1_1_base.html#a6474cd9a38f897d3fc7281332870ffbc", null ],
    [ "owns", "class_sensor_logic_1_1_base.html#aaf1a6428bf9352cbfe5a2a53c330f4d6", null ]
];
var compat_8hpp =
[
    [ "INITIALIZER", "compat_8hpp.html#a8e1958511f31a98a5bb11bc7e34d7696", null ],
    [ "PRETTYFUNC", "compat_8hpp.html#a38c97dd9052c61441dc20539e20b7c53", null ],
    [ "microsleep", "compat_8hpp.html#a8bc1f73882a96927d6ad652385561cd9", null ],
    [ "yield", "compat_8hpp.html#ad3308802a5b0951142e29de85abce3e3", null ]
];
var namespace_camera =
[
    [ "Channel", "class_camera_1_1_channel.html", "class_camera_1_1_channel" ],
    [ "ChannelImpl", "class_camera_1_1_channel_impl.html", "class_camera_1_1_channel_impl" ],
    [ "ChannelImplManager", "class_camera_1_1_channel_impl_manager.html", "class_camera_1_1_channel_impl_manager" ],
    [ "ConfigPath", "class_camera_1_1_config_path.html", "class_camera_1_1_config_path" ],
    [ "Device", "class_camera_1_1_device.html", "class_camera_1_1_device" ],
    [ "Object", "class_camera_1_1_object.html", "class_camera_1_1_object" ]
];
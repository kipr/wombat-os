var class_sensor_logic_1_1_not =
[
    [ "Not", "class_sensor_logic_1_1_not.html#a3bf67b05c366eb497cddcec613b78b54", null ],
    [ "~Not", "class_sensor_logic_1_1_not.html#aba552144d268882b98b627850b9ef795", null ],
    [ "input", "class_sensor_logic_1_1_not.html#a24d748493d82c0cda05ef068e38f348f", null ],
    [ "owns", "class_sensor_logic_1_1_not.html#a51b0628680fce6076055b65c33196dcb", null ],
    [ "value", "class_sensor_logic_1_1_not.html#a2374c54d28093fa68d3dab51727ecfb5", null ]
];
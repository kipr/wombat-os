var structkipr_create3_client_Pose =
[
    [ "position", "structkipr_create3_client_Pose.html#a153ee6bc0e148a129ab7d0adda859b3a", null ],
    [ "orientation", "structkipr_create3_client_Pose.html#a14175fc7bc9adacb3269fc71f8f62a3a", null ],
    [ "create3_navigate_to_pose", "structkipr_create3_client_Pose.html#ga7abc2298660a0c95e911de24771a5623", null ],
    [ "create3_pose_get", "structkipr_create3_client_Pose.html#gab8d4d522ae0855ca565f59c549e0052d", null ],


];
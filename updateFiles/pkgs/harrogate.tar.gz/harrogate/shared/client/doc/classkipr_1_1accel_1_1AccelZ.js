var classkipr_1_1accel_1_1AccelZ =
[
    [ "value", "classkipr_1_1accel_1_1AccelZ.html#a69d636d692af591a9b61f6c73209f1be", null ]
];
var structkipr_1_1create_1_1CreatePackets_1_1__2 =
[
    [ "angle", "structkipr_1_1create_1_1CreatePackets_1_1__2.html#a4a56857548f13dcdcdc4dcb2f203bd87", null ],
    [ "buttons", "structkipr_1_1create_1_1CreatePackets_1_1__2.html#a44febc62685bafda264471cfe9653fdd", null ],
    [ "distance", "structkipr_1_1create_1_1CreatePackets_1_1__2.html#af58f25943c9c27fdee9165ee086fa381", null ],
    [ "ir", "structkipr_1_1create_1_1CreatePackets_1_1__2.html#a2dc25387dc7732397ee921696a1023f4", null ]
];
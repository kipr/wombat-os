var client_8hpp =
[
    ["kirp::create3::client::Client", "classkipr_1_1create3_1_1client_Client.html", null ],
    ["kirp::create3::client::ClientImpl", "structkipr_create3_client_ClientImpl.html", null ],
    ["kirp::create3::client::Stamped", "structkipr_create3_client_Stamped.html", null ],

];
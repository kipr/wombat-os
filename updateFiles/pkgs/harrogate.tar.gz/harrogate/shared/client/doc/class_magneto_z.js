var class_magneto_z =
[
    [ "value", "class_magneto_z.html#ad122db2265e0fc3060ef436d584da74e", null ]
];
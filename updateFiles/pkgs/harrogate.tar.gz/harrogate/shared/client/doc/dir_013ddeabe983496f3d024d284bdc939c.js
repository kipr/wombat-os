var dir_013ddeabe983496f3d024d284bdc939c =
[
    [ "kipr", "dir_95b156f08594208fe53b46b1b7eaac01.html", "dir_95b156f08594208fe53b46b1b7eaac01" ]
];
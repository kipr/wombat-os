var dir_7df3fbfdec0ff5445026d64f470b7da0 =
[
    [ "analog.h", "analog_8h.html", "analog_8h" ],
    [ "analog.hpp", "analog_8hpp.html", [
      [ "Analog", "classkipr_1_1analog_1_1Analog.html", "classkipr_1_1analog_1_1Analog" ],
      [ "Analog8", "classkipr_1_1analog_1_1Analog8.html", "classkipr_1_1analog_1_1Analog8" ],
      [ "Analog10", "classkipr_1_1analog_1_1Analog10.html", "classkipr_1_1analog_1_1Analog10" ]
    ] ]
];
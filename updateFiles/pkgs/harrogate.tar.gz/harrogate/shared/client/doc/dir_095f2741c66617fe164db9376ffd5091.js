var dir_095f2741c66617fe164db9376ffd5091 =
[
    [ "battery.h", "battery_8h.html", "battery_8h" ],
    [ "battery.hpp", "battery_8hpp.html", [
      [ "Battery", "classkipr_1_1battery_1_1Battery.html", null ]
    ] ]
];
var classkipr_1_1accel_1_1AccelY =
[
    [ "value", "classkipr_1_1accel_1_1AccelY.html#a9071fe4d711df8d6c4d6394aedafd35d", null ]
];
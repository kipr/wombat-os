var classkipr_1_1camera_1_1Device =
[
    [ "Device", "classkipr_1_1camera_1_1Device.html#ab8340db845610668ea2a1234cdc876fc", null ],
    [ "~Device", "classkipr_1_1camera_1_1Device.html#ab94d8c1547dcc8e60c54eb3ce0737b59", null ],
    [ "bgr", "classkipr_1_1camera_1_1Device.html#a4c0da5e756d2a8b49c640795855216ca", null ],
    [ "channels", "classkipr_1_1camera_1_1Device.html#ae039211ccba96b22d3711495d7c284e7", null ],
    [ "close", "classkipr_1_1camera_1_1Device.html#ad066f6bd3abcb8acc6e4b249c1096c0e", null ],
    [ "config", "classkipr_1_1camera_1_1Device.html#abdea7ac114a288e6f7cb639ac17abc75", null ],
    [ "getModel", "classkipr_1_1camera_1_1Device.html#a66d8d92891fcd9eb12a4c1b59acf44c3", null ],
    [ "height", "classkipr_1_1camera_1_1Device.html#af1e2c3d6dff6556b4949f41ab2af2840", null ],
    [ "isOpen", "classkipr_1_1camera_1_1Device.html#ab56953ca6a20d3a13142b28964b85e98", null ],
    [ "open", "classkipr_1_1camera_1_1Device.html#a118c537d828e0d098ab829c6041f5db7", null ],
    [ "rawImage", "classkipr_1_1camera_1_1Device.html#a0113a90b22919ee3cc1241851ae14a78", null ],
    [ "setConfig", "classkipr_1_1camera_1_1Device.html#a56a6c297ed3eeffd3b65a06c27b776ea", null ],
    [ "update", "classkipr_1_1camera_1_1Device.html#a0162f7920f865c52e95814c6cd840e0e", null ],
    [ "width", "classkipr_1_1camera_1_1Device.html#a773e4633517d2b9579a991ee40b50d2d", null ]
];
var dir_d27129b8d398856e7122440405d66deb =
[
    [ "logic.hpp", "logic_8hpp.html", [
      [ "Base", "classkipr_1_1sensor_1_1logic_1_1Base.html", "classkipr_1_1sensor_1_1logic_1_1Base" ],
      [ "And", "classkipr_1_1sensor_1_1logic_1_1And.html", "classkipr_1_1sensor_1_1logic_1_1And" ],
      [ "Or", "classkipr_1_1sensor_1_1logic_1_1Or.html", "classkipr_1_1sensor_1_1logic_1_1Or" ],
      [ "Xor", "classkipr_1_1sensor_1_1logic_1_1Xor.html", "classkipr_1_1sensor_1_1logic_1_1Xor" ],
      [ "Not", "classkipr_1_1sensor_1_1logic_1_1Not.html", "classkipr_1_1sensor_1_1logic_1_1Not" ]
    ] ],
    [ "sensor.hpp", "sensor_8hpp.html", [
      [ "Sensor", "classkipr_1_1sensor_1_1Sensor.html", "classkipr_1_1sensor_1_1Sensor" ]
    ] ]
];
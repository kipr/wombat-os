var structkipr_1_1create_1_1CreatePackets_1_1__101 =
[
    [ "leftEncoderCounts", "structkipr_1_1create_1_1CreatePackets_1_1__101.html#abd175d3f0f247c3587bee4fc1426ae70", null ],
    [ "leftMotorCurrent", "structkipr_1_1create_1_1CreatePackets_1_1__101.html#ae1e5de7bc53fc50eb4d7f25c172e8e22", null ],
    [ "lightBumpBits", "structkipr_1_1create_1_1CreatePackets_1_1__101.html#ac54b84c4e01169307eb15152482bdfc3", null ],
    [ "lightBumpCenterLeftSignal", "structkipr_1_1create_1_1CreatePackets_1_1__101.html#aeefbb0e939ecd1e3548f9fef43266101", null ],
    [ "lightBumpCenterRightSignal", "structkipr_1_1create_1_1CreatePackets_1_1__101.html#a26dc3d20e8da55c6b2293bc7fb0f616f", null ],
    [ "lightBumpFrontLeftSignal", "structkipr_1_1create_1_1CreatePackets_1_1__101.html#a7f97bcbbd1be9384205b645aede69e13", null ],
    [ "lightBumpFrontRightSignal", "structkipr_1_1create_1_1CreatePackets_1_1__101.html#acb22bb2faba42e0ca5fd8516e3567fea", null ],
    [ "lightBumpLeftSignal", "structkipr_1_1create_1_1CreatePackets_1_1__101.html#aa9c10b2ad38882e04d49673a7dc1a48c", null ],
    [ "lightBumpRightSignal", "structkipr_1_1create_1_1CreatePackets_1_1__101.html#a0114a80c832e2ecce3c82bf6cdfe8e2b", null ],
    [ "mainBrushMotorCurrent", "structkipr_1_1create_1_1CreatePackets_1_1__101.html#a32c55cb5c8409f20b688b09eba0055a8", null ],
    [ "rightEncoderCounts", "structkipr_1_1create_1_1CreatePackets_1_1__101.html#a1ed08b26b8cc371ef927409c9b96f2b6", null ],
    [ "rightMotorCurrent", "structkipr_1_1create_1_1CreatePackets_1_1__101.html#a7c4556fc8214e4c0ffb04498d9c97c6e", null ],
    [ "sideBrushMotorCurrent", "structkipr_1_1create_1_1CreatePackets_1_1__101.html#a943e23e55c6bfe066f933d6283105e2f", null ],
    [ "stasis", "structkipr_1_1create_1_1CreatePackets_1_1__101.html#ab56c5b32418341093e47698c39c61026", null ]
];
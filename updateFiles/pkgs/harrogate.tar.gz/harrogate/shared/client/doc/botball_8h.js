var botball_8h =
[
    [ "shut_down_in", "botball_8h.html#a27709aff1cbaf8ea25b672afcb8920e9", null ],
    [ "wait_for_light", "botball_8h.html#a706027d852569bb8e4887c0919252150", null ]
];
var class_camera_1_1_object =
[
    [ "Object", "class_camera_1_1_object.html#ae62cb68e3cc16bcf08812f0a64ba75dc", null ],
    [ "Object", "class_camera_1_1_object.html#ad721a78cffe2c028cf26940c1ae8b3c9", null ],
    [ "~Object", "class_camera_1_1_object.html#a3772184b08cf3c84753bd698d493b704", null ],
    [ "boundingBox", "class_camera_1_1_object.html#a162246525f8f801e961ec29dee4d7c30", null ],
    [ "centroid", "class_camera_1_1_object.html#a91d630f5ae5b25af37749a50a591cda5", null ],
    [ "confidence", "class_camera_1_1_object.html#a9eef5a99a8ab77fc4d4baaa31b1ac21b", null ],
    [ "data", "class_camera_1_1_object.html#a73d0a5d752a5a772e811bbed43d7c5ff", null ],
    [ "dataLength", "class_camera_1_1_object.html#a64099db7277073e0cd809621adb372e0", null ]
];
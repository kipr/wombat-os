var classkipr_1_1sensor_1_1logic_1_1Or =
[
    [ "Or", "classkipr_1_1sensor_1_1logic_1_1Or.html#a94eb56dbc145c66018f96eed9fa59d42", null ],
    [ "value", "classkipr_1_1sensor_1_1logic_1_1Or.html#a89d77eecfac650b7b66d1d8857f93aed", null ]
];
var classkipr_1_1camera_1_1Channel =
[
    [ "Channel", "classkipr_1_1camera_1_1Channel.html#a765ef12a60bf6a0f5169d4412085aab5", null ],
    [ "~Channel", "classkipr_1_1camera_1_1Channel.html#a306b2abe849577a673dd7abb53ea41ea", null ],
    [ "device", "classkipr_1_1camera_1_1Channel.html#a517356703db0377b642e94ccf6fa0b3e", null ],
    [ "invalidate", "classkipr_1_1camera_1_1Channel.html#ada5351bbea8bb382391ebcb2d34c3f41", null ],
    [ "objects", "classkipr_1_1camera_1_1Channel.html#ae063189132bf9c29e0e43e2e57e0a0cc", null ],
    [ "setConfig", "classkipr_1_1camera_1_1Channel.html#ad430a7ad4de39b67be67c12fd26684bc", null ]
];
var dir_05c01e65d4a1408859c72bd5206fe4fe =
[
    [ "config.hpp", "config_8hpp.html", [
      [ "Config", "classkipr_1_1config_1_1Config.html", "classkipr_1_1config_1_1Config" ]
    ] ]
];
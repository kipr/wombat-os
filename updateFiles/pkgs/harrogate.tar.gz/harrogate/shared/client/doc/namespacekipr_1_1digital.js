var namespacekipr_1_1digital =
[
    [ "Digital", "classkipr_1_1digital_1_1Digital.html", "classkipr_1_1digital_1_1Digital" ]
];
var struct_create_state =
[
    [ "angle", "struct_create_state.html#a504acb47a81921a9d6c23edc83d64a3f", null ],
    [ "distance", "struct_create_state.html#a0154ed42d271cca3c9a095bf3468686c", null ],
    [ "leftVelocity", "struct_create_state.html#a5d39d2a60ba7436343797b895790e5bd", null ],
    [ "radius", "struct_create_state.html#afd60a9df4dbc51303fcd2dea384b2226", null ],
    [ "rightVelocity", "struct_create_state.html#a0cf4e85144adf2c52769f56bf01c0b1b", null ],
    [ "timestamp", "struct_create_state.html#a7bb273a330222608dbaf4a7dd38c1451", null ]
];
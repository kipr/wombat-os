var namespacekipr_1_1compass =
[
    [ "Compass", "classkipr_1_1compass_1_1Compass.html", "classkipr_1_1compass_1_1Compass" ]
];
var classkipr_1_1create3_1_1client_Client =
[
    [ "r", "structkipr_create3_client_LedColor.html#a4feece2ec58d909444613177ec67e2bc", null ],
    [ "g", "structkipr_create3_client_LedColor.html#ac537f5c6afbda6ef42cc428540058ecb", null ],
    [ "b", "structkipr_create3_client_LedColor.html#ax6ehp4fks013b85qvtjmceb7f2y24fp", null ],
    [ "create3_led_color", "structkipr_create3_client_LedColor.html#ga7abc2298660a0c95e911de24771a5623", null ],
    [ "create3_lightring", "structkipr_create3_client_LedColor.html#gab8d4d522ae0855ca565f59c549e0052d", null ],
];
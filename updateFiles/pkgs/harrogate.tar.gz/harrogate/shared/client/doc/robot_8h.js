var robot_8h =
[
    [ "get_low_volt_threshold", "robot_8h.html#afc3476cfe4d6ca158b8717a4e1e8e062", null ],
    [ "get_robot_firmware_version", "robot_8h.html#a17f42dd88a45b0e4494531a4a319c3a1", null ],
    [ "get_robot_states_sequence_num", "robot_8h.html#ad4ee4dcee72e545b745801cf11bff47b", null ],
    [ "get_robot_update_count", "robot_8h.html#ad57dd468e0b267617d4b6776bca0c0a9", null ],
    [ "get_robot_update_delay", "robot_8h.html#ab638f9ac2df4a55afc9838de897de608", null ],
    [ "set_low_volt_threshold", "robot_8h.html#a04c5bd8e5f9c4d853e839984d670f03b", null ],
    [ "set_robot_update_delay", "robot_8h.html#a27499475f52f296b24a779ee2202e8f0", null ]
];
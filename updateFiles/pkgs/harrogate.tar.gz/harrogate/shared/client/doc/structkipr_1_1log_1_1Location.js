var structkipr_1_1log_1_1Location =
[
    [ "column", "structkipr_1_1log_1_1Location.html#a0c034bb23a30b19e2163bb2e822a5e0f", null ],
    [ "file", "structkipr_1_1log_1_1Location.html#ae38b3f501c4a6057675590920634fe31", null ],
    [ "line", "structkipr_1_1log_1_1Location.html#aa9898336f46294adcc8bf30f17200ba3", null ]
];
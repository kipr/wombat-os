var structkipr_create3_client_Odometry =
[
    [ "pose", "structkipr_create3_client_Odometry.html#a4feece2ec58d909444613177ec67e2bc", null ],
    [ "velocity", "structkipr_create3_client_Odometry.html#ac537f5c6afbda6ef42cc428540058ecb", null ],
    [ "create3_odometry_get", "structkipr_create3_client_Odometry.html#ga7abc2298660a0c95e911de24771a5623", null ],


];
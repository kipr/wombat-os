var group__battery =
[
    [ "", "group__battery.html", null ],
    [ "battery_charging", "group__battery.html#ga00b9c876fa198ae3485c44eb7ca92519", null ],
    [ "power_level", "group__battery.html#gae1ca31cc83102eaaeaf1afa62a15abb6", null ],
    [ "power_level_life", "group__battery.html#ga2998e0fd731d4c46608ffbea835e6f03", null ],
    [ "power_level_lipo", "group__battery.html#gafed7c1f128056008a75719ff634a1af4", null ],
    [ "power_level_nimh", "group__battery.html#ga4240f318b6aaab523f4947ad1314ef15", null ]
];
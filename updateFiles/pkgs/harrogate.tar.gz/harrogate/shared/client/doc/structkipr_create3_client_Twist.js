var structkipr_create3_client_Twist =
[
    [ "linear_x", "structkipr_create3_client_Twist.html#af460193d9a375b8e2813bf1fe6216cce", null ],
    [ "angular_z", "structkipr_create3_client_Twist.html#a4feece2ec58d909444613177ec67e2bc", null ],
    [ "create3_velocity_get", "structkipr_create3_client_Twist.html#ga7abc2298660a0c95e911de24771a5623", null ],
    [ "create3_velocity_set", "structkipr_create3_client_Twist.html#gab8d4d522ae0855ca565f59c549e0052d", null ],
];
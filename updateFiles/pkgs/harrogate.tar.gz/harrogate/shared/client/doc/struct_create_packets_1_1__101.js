var struct_create_packets_1_1__101 =
[
    [ "leftEncoderCounts", "struct_create_packets_1_1__101.html#a0aa4a3ac2cf3b7006b4fd5b370122ce0", null ],
    [ "leftMotorCurrent", "struct_create_packets_1_1__101.html#a8985f447e1f995b941dbe81b9539f5d7", null ],
    [ "lightBumpBits", "struct_create_packets_1_1__101.html#acdc512f02007e22c3c3bf6581db69c77", null ],
    [ "lightBumpCenterLeftSignal", "struct_create_packets_1_1__101.html#a94b792cbd2a9ae14cc2b8ba763815cb2", null ],
    [ "lightBumpCenterRightSignal", "struct_create_packets_1_1__101.html#ad88df60e39da46fa36abc75374da65ec", null ],
    [ "lightBumpFrontLeftSignal", "struct_create_packets_1_1__101.html#aa4173cdf7c3007a3a11407a6b4c8b0ab", null ],
    [ "lightBumpFrontRightSignal", "struct_create_packets_1_1__101.html#a9a995c7e4ce9dba61d951bf644f702d2", null ],
    [ "lightBumpLeftSignal", "struct_create_packets_1_1__101.html#a726fb8e1cdace2b54e5f5b3d4e3ee87f", null ],
    [ "lightBumpRightSignal", "struct_create_packets_1_1__101.html#aaddc3918584989b7b514f16c4dd4f57a", null ],
    [ "mainBrushMotorCurrent", "struct_create_packets_1_1__101.html#a0cbb83f589f640d0093df33b7a27a051", null ],
    [ "rightEncoderCounts", "struct_create_packets_1_1__101.html#adbb2919c3a5cad726f1e98ea387ce571", null ],
    [ "rightMotorCurrent", "struct_create_packets_1_1__101.html#a1d5466dea7e0be8dcf9c0adae8bfb8aa", null ],
    [ "sideBrushMotorCurrent", "struct_create_packets_1_1__101.html#a295b81e53ddce8ab5a068a092c736285", null ],
    [ "stasis", "struct_create_packets_1_1__101.html#a0bfe6bcefb8d4e0806ef74a96156df2e", null ]
];
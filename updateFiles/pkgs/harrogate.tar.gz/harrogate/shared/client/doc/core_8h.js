var core_8h =
[
    [ "kipr_build_datetime", "core_8h.html#a3b11d13df2fb38ee31746362e189a287", null ],
    [ "kipr_git_branch", "core_8h.html#ac1b158abd8977a7a47c57341884da0e1", null ],
    [ "kipr_git_commit_hash", "core_8h.html#a078b4d94ae27925754c8e2dbfdddf7a2", null ],
    [ "kipr_version", "core_8h.html#a68e2b885bfc29b9d15eb7434e313217d", null ],
    [ "kipr_version_major", "core_8h.html#ac8383a59b1dae0edcfadc8d0c6a7f5b8", null ],
    [ "kipr_version_minor", "core_8h.html#a9477fdfa9af0446ef6a75afa16784063", null ],
    [ "kipr_version_patch", "core_8h.html#a88391ac44169cedf09a70854c1dc6f2d", null ]
];
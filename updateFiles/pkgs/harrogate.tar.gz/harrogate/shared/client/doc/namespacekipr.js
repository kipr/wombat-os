var namespacekipr =
[
    [ "accel", "namespacekipr_1_1accel.html", "namespacekipr_1_1accel" ],
    [ "analog", "namespacekipr_1_1analog.html", "namespacekipr_1_1analog" ],
    [ "battery", "namespacekipr_1_1battery.html", "namespacekipr_1_1battery" ],
    [ "button", "namespacekipr_1_1button.html", "namespacekipr_1_1button" ],
    [ "camera", "namespacekipr_1_1camera.html", "namespacekipr_1_1camera" ],
    [ "compass", "namespacekipr_1_1compass.html", "namespacekipr_1_1compass" ],
    [ "config", "namespacekipr_1_1config.html", "namespacekipr_1_1config" ],
    [ "console", "namespacekipr_1_1console.html", "namespacekipr_1_1console" ],
    [ "create", "namespacekipr_1_1create.html", "namespacekipr_1_1create" ],
    [ "create3", "namespacekipr_1_1create3.html", "namespacekipr_1_1create3" ],
    [ "digital", "namespacekipr_1_1digital.html", "namespacekipr_1_1digital" ],
    [ "geometry", "namespacekipr_1_1geometry.html", "namespacekipr_1_1geometry" ],
    [ "gyro", "namespacekipr_1_1gyro.html", "namespacekipr_1_1gyro" ],
    [ "log", "namespacekipr_1_1log.html", "namespacekipr_1_1log" ],
    [ "magneto", "namespacekipr_1_1magneto.html", "namespacekipr_1_1magneto" ],
    [ "motor", "namespacekipr_1_1motor.html", "namespacekipr_1_1motor" ],
    [ "sensor", "namespacekipr_1_1sensor.html", "namespacekipr_1_1sensor" ],
    [ "servo", "namespacekipr_1_1servo.html", "namespacekipr_1_1servo" ],
    [ "thread", "namespacekipr_1_1thread.html", "namespacekipr_1_1thread" ]
];
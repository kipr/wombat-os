var namespace_create_packets =
[
    [ "_1", "struct_create_packets_1_1__1.html", "struct_create_packets_1_1__1" ],
    [ "_101", "struct_create_packets_1_1__101.html", "struct_create_packets_1_1__101" ],
    [ "_2", "struct_create_packets_1_1__2.html", "struct_create_packets_1_1__2" ],
    [ "_3", "struct_create_packets_1_1__3.html", "struct_create_packets_1_1__3" ],
    [ "_4", "struct_create_packets_1_1__4.html", "struct_create_packets_1_1__4" ],
    [ "_5", "struct_create_packets_1_1__5.html", "struct_create_packets_1_1__5" ]
];
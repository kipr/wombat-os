var class_back_e_m_f =
[
    [ "BackEMF", "class_back_e_m_f.html#af8f119cd1fdfd3cb319cadd265e9b231", null ],
    [ "port", "class_back_e_m_f.html#a01436d8265ea5c68cfd0166bf252e32f", null ],
    [ "value", "class_back_e_m_f.html#a6381060fa74f20567e31aebee56ca3e6", null ]
];
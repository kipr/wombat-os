var debug_8h =
[
    [ "debug_dump_data", "debug_8h.html#ad1bf27ac39ed19e38732859c3cfeefdb", null ],
    [ "debug_print_registers", "debug_8h.html#a94976d67ec31c6101b15447274dc3bbe", null ],
    [ "register_value", "debug_8h.html#a741ac2c9bcc99558c55e0ad27577c50b", null ]
];
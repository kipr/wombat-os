var namespacekipr_1_1create3_1_1client =
[
    [ "AudioNote", "structkipr_create3_client_AudioNote.html", "structkipr_create3_client_AudioNote" ],
    [ "Client", "classkipr_1_1create3_1_1client_Client.html", "classkipr_1_1create3_1_1client_Client" ],
    [ "ClientImpl", "structkipr_create3_client_ClientImpl.html", "structkipr_create3_client_ClientImpl" ],
    [ "Follow", "structkipr_create3_client_Follow.html", "structkipr_create3_client_Follow" ],
    [ "LedAnimationType", "structkipr_create3_client_LedAnimationType.html", "structkipr_create3_client_LedAnimationType" ],
    [ "LedColor", "structkipr_create3_client_LedColor.html", "structkipr_create3_client_LedColor" ],
    [ "Lightring", "structkipr_create3_client_Lightring.html", "structkipr_create3_client_Lightring" ],
    [ "LocalClientImpl", "structkipr_create3_client_LocalClientImpl.html", "structkipr_create3_client_LocalClientImpl" ],
    [ "Odometry", "structkipr_create3_client_Odometry.html", "structkipr_create3_client_Odometry" ],
    [ "Pose", "structkipr_create3_client_Pose.html", "structkipr_create3_client_Pose" ],
    [ "Quaternion", "structkipr_create3_client_Quaternion.html", "structkipr_create3_client_Quaternion" ],
    [ "RemoteClientImpl", "structkipr_create3_client_RemoteClientImpl.html", "structkipr_create3_client_RemoteClientImpl" ],
    [ "Stamped", "structkipr_create3_client_Stamped.html", "structkipr_create3_client_Stamped" ],
    [ "Twist", "structkipr_create3_client_Twist.html", "structkipr_create3_client_Twist" ],
    [ "Vector3", "structkipr_create3_client_Vector3.html", "structkipr_create3_client_Vector3" ],
];
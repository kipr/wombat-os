var audioNote_8hpp =
[
    [ "kirp::create3::client::AudioNote", "structkipr_create3_client_AudioNote.html", null ],
];
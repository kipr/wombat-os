var classkipr_1_1camera_1_1Image =
[
    [ "Type", "classkipr_1_1camera_1_1Image.html#afe6b96cc9cb2321c5d9c2c2bfd43aa7d", [
      [ "Grey8", "classkipr_1_1camera_1_1Image.html#afe6b96cc9cb2321c5d9c2c2bfd43aa7daeaa0c2dba26f32ed75d41b88a18f54d0", null ],
      [ "Rgb888", "classkipr_1_1camera_1_1Image.html#afe6b96cc9cb2321c5d9c2c2bfd43aa7da9d1893c14faa5ff4f069b90de91d4e07", null ],
      [ "Bgr888", "classkipr_1_1camera_1_1Image.html#afe6b96cc9cb2321c5d9c2c2bfd43aa7da9343f7b5444442a0025562a2b8bacbec", null ]
    ] ],
    [ "Image", "classkipr_1_1camera_1_1Image.html#a110a9d6d4c9a1e77cdc3776d5a0a0cca", null ],
    [ "Image", "classkipr_1_1camera_1_1Image.html#ae86240df12c553157d18a8a38d67544b", null ],
    [ "Image", "classkipr_1_1camera_1_1Image.html#a6d30fd7caaa3676f28b3b8cd9470deda", null ],
    [ "Image", "classkipr_1_1camera_1_1Image.html#a06eab8916cf119cd3d7971046866bac5", null ],
    [ "~Image", "classkipr_1_1camera_1_1Image.html#a141da1b5048556274661bf0126c9bfcf", null ],
    [ "getData", "classkipr_1_1camera_1_1Image.html#a3981607641bbf06e5b22613d6308d2e4", null ],
    [ "getHeight", "classkipr_1_1camera_1_1Image.html#a28c0fbc833f933744737e6f05d806371", null ],
    [ "getStride", "classkipr_1_1camera_1_1Image.html#ac2f8ee5c47d60065aec1d96a2afe1e8d", null ],
    [ "getType", "classkipr_1_1camera_1_1Image.html#ad86abed411d598b4e2a828abac933d08", null ],
    [ "getWidth", "classkipr_1_1camera_1_1Image.html#a4b089f3da6a3be3173df2cac368e0240", null ],
    [ "isEmpty", "classkipr_1_1camera_1_1Image.html#a1f19cd6005eced215522a3c7e4a2e0b7", null ],
    [ "isOwned", "classkipr_1_1camera_1_1Image.html#a48eb100e4105464f2bc9cb4626178607", null ],
    [ "operator=", "classkipr_1_1camera_1_1Image.html#a409957a1ef82879d478efbce560b05ca", null ],
    [ "swap", "classkipr_1_1camera_1_1Image.html#a2ada16b35bebf315fd5c901e19044220", null ]
];
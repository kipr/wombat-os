var structkipr_1_1create_1_1CreatePackets_1_1__4 =
[
    [ "chargingSourcesAvailable", "structkipr_1_1create_1_1CreatePackets_1_1__4.html#a5e211cdf97324b5c9defbd04112eff65", null ],
    [ "cliffFrontLeftSignal", "structkipr_1_1create_1_1CreatePackets_1_1__4.html#ad2079b6d72c9116f6751b4ce8f878504", null ],
    [ "cliffFrontRightSignal", "structkipr_1_1create_1_1CreatePackets_1_1__4.html#ad563283181a7d7b2cf2bd91a19ce790d", null ],
    [ "cliffLeftSignal", "structkipr_1_1create_1_1CreatePackets_1_1__4.html#a1483df2fc961addb716f8199616fce7e", null ],
    [ "cliffRightSignal", "structkipr_1_1create_1_1CreatePackets_1_1__4.html#ac3b34b2d5f12e26aee81dff2ba70be0e", null ],
    [ "userAnalogInput", "structkipr_1_1create_1_1CreatePackets_1_1__4.html#ae3479f06571488e5a4abd25633ac695e", null ],
    [ "userDigitalInputs", "structkipr_1_1create_1_1CreatePackets_1_1__4.html#afb1cd7c49aa3713d6702536e9a0cabb8", null ],
    [ "wallSignal", "structkipr_1_1create_1_1CreatePackets_1_1__4.html#a3a3b2fb131b855a9d707cfc4b4aab40c", null ]
];
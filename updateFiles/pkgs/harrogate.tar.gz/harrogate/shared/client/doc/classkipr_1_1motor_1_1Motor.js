var classkipr_1_1motor_1_1Motor =
[
    [ "Motor", "classkipr_1_1motor_1_1Motor.html#a18685ec996c646e881d44b56c756111a", null ],
    [ "baasbennaguui", "classkipr_1_1motor_1_1Motor.html#af0b65791641c390f87d2d774767208df", null ],
    [ "backward", "classkipr_1_1motor_1_1Motor.html#af7c3c7b4a11497e68c37402de8300455", null ],
    [ "blockMotorDone", "classkipr_1_1motor_1_1Motor.html#ab72ac3d2ee3a9f6c53a3471770f5bd75", null ],
    [ "clearPositionCounter", "classkipr_1_1motor_1_1Motor.html#ae38c11a12eca0ce953d40af2f552a12c", null ],
    [ "forward", "classkipr_1_1motor_1_1Motor.html#ab7643ecdc777b105f46208a2f5a838d3", null ],
    [ "freeze", "classkipr_1_1motor_1_1Motor.html#a32a7e6f957875a1f8509c4155a4c79cd", null ],
    [ "isMotorDone", "classkipr_1_1motor_1_1Motor.html#a80b581d95ef3783b3f4176d932ed2ec2", null ],
    [ "motor", "classkipr_1_1motor_1_1Motor.html#a0a799c4cf7dff5ca53e8317fb8d3ff72", null ],
    [ "motorPower", "classkipr_1_1motor_1_1Motor.html#acb2e3785fdbf7b50857f65b16d06f6d4", null ],
    [ "moveAtVelocity", "classkipr_1_1motor_1_1Motor.html#acb479b07528e755bcacf78509b7388c0", null ],
    [ "moveRelativePosition", "classkipr_1_1motor_1_1Motor.html#a41ff4456f5fff373f35da0bc5857c518", null ],
    [ "moveToPosition", "classkipr_1_1motor_1_1Motor.html#ad5743532f303261eddba2981c61bc679", null ],
    [ "off", "classkipr_1_1motor_1_1Motor.html#afa7c31efb374ac08b3dd7097ae82e2be", null ],
    [ "pidGains", "classkipr_1_1motor_1_1Motor.html#a411b3fbb39e0a7e25e355e213616211e", null ],
    [ "port", "classkipr_1_1motor_1_1Motor.html#a162aa66d2994a6e83e96b794d2e8b623", null ],
    [ "setPidGains", "classkipr_1_1motor_1_1Motor.html#adc673d5343e29c1796aa1376ee875cc0", null ]
];
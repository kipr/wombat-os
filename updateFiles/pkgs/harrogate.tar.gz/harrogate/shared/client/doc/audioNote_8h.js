var audioNote_8h =
[
    ["Create3AudioNote", "structkipr_create3_client_AudioNote.html", null ],

];
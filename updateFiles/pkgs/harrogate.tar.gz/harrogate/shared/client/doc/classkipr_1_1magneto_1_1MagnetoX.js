var classkipr_1_1magneto_1_1MagnetoX =
[
    [ "value", "classkipr_1_1magneto_1_1MagnetoX.html#abc707a04f6f0cc0d31a4bb0f103aac16", null ]
];
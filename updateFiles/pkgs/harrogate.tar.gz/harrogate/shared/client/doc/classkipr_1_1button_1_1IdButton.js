var classkipr_1_1button_1_1IdButton =
[
    [ "IdButton", "classkipr_1_1button_1_1IdButton.html#ae0ff6af79e67ad95ee0f376ec12e1bea", null ],
    [ "~IdButton", "classkipr_1_1button_1_1IdButton.html#a67b1d1ffbcdf862eeda4d652ac2628fb", null ],
    [ "isTextDirty", "classkipr_1_1button_1_1IdButton.html#a790eaead998d029d7e4105b5013f14bc", null ],
    [ "resetText", "classkipr_1_1button_1_1IdButton.html#a1be37f44c07b4b7b58064c2f687d824b", null ],
    [ "setPressed", "classkipr_1_1button_1_1IdButton.html#a96fd76a2831a56b9c383f04260067749", null ],
    [ "setText", "classkipr_1_1button_1_1IdButton.html#ac6cea0dd9f461e929ba35b755fe9e16c", null ],
    [ "text", "classkipr_1_1button_1_1IdButton.html#a5ac78344ad2d2638005c475456242658", null ],
    [ "value", "classkipr_1_1button_1_1IdButton.html#a1efe92321fc819e139b353cabb0d6940", null ]
];
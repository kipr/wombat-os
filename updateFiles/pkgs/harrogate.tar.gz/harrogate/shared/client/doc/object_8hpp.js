var object_8hpp =
[
    [ "Object", "classkipr_1_1camera_1_1Object.html", "classkipr_1_1camera_1_1Object" ],
    [ "ObjectVector", "object_8hpp.html#ab5b03a717a191c7377854e2518658748", null ]
];
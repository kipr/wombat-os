var dir_671bd19ce3ce27d652ded3bb772f9da6 =
[
    [ "battery", "dir_095f2741c66617fe164db9376ffd5091.html", "dir_095f2741c66617fe164db9376ffd5091" ]
];
var structkipr_1_1create_1_1CreatePackets_1_1__5 =
[
    [ "leftVelocity", "structkipr_1_1create_1_1CreatePackets_1_1__5.html#a37f03a9d3628b51279185ae2ad9315fb", null ],
    [ "mode", "structkipr_1_1create_1_1CreatePackets_1_1__5.html#a8b014d11b83159a5801ea91049a63cfb", null ],
    [ "numberOfStreamPackets", "structkipr_1_1create_1_1CreatePackets_1_1__5.html#a3adfda31b1536fa76a2638acf0293b2e", null ],
    [ "radius", "structkipr_1_1create_1_1CreatePackets_1_1__5.html#a29f094d582f2b54356b5b2ae42eb4121", null ],
    [ "rightVelocity", "structkipr_1_1create_1_1CreatePackets_1_1__5.html#adfa7a25f7d2e4bfbb4ed696b36989f6d", null ],
    [ "songNumber", "structkipr_1_1create_1_1CreatePackets_1_1__5.html#a46a2ae15f1fe54f42d163c8924b68bba", null ],
    [ "songPlaying", "structkipr_1_1create_1_1CreatePackets_1_1__5.html#afd57fbd17b67aa012b4be688c1278a54", null ],
    [ "velocity", "structkipr_1_1create_1_1CreatePackets_1_1__5.html#a89b049afbd52b09591a5c3cf37da0a9c", null ]
];
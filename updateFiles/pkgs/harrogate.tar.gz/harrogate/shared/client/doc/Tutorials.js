var Tutorials =
[
    [ "Module Tutorials", "Tutorials.html#module_tutorials", null ],
    [ "Comprehensive Tutorials", "Tutorials.html#complete_tutorials", null ],
    [ "Getting Started", "getting_started.html", null ],
    [ "Sensors Tutorials", "sensors_tutorial.html", [
      [ "Sensor Types", "sensors_tutorial.html#sensor_types", [
        [ "Analog Sensors", "sensors_tutorial.html#analog_sensors", null ],
        [ "Digital Sensors", "sensors_tutorial.html#digital_sensors", null ]
      ] ]
    ] ]
];
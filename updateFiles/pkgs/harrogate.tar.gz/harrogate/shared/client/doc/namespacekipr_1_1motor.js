var namespacekipr_1_1motor =
[
    [ "Motor", "classkipr_1_1motor_1_1Motor.html", "classkipr_1_1motor_1_1Motor" ],
    [ "BackEMF", "classkipr_1_1motor_1_1BackEMF.html", "classkipr_1_1motor_1_1BackEMF" ],
    [ "MOTOR_COUNT", "namespacekipr_1_1motor.html#aa56c71ecc5579a9d8838f42b908da6c4", null ]
];
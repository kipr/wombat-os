var classkipr_1_1geometry_1_1Point2 =
[
    [ "Point2", "classkipr_1_1geometry_1_1Point2.html#a2298f26854e113f4d27fcb58e75be94f", null ],
    [ "column", "classkipr_1_1geometry_1_1Point2.html#a4fb598468c383eddcc822068ae778a8a", null ],
    [ "row", "classkipr_1_1geometry_1_1Point2.html#a4e6aee197b3c5c6d1995eb0c51dac5c7", null ],
    [ "setColumn", "classkipr_1_1geometry_1_1Point2.html#ab177cecf8aa32c8b0d951c230483021c", null ],
    [ "setRow", "classkipr_1_1geometry_1_1Point2.html#a1d5e476702c94aaa4a099e949f10f6dc", null ],
    [ "setX", "classkipr_1_1geometry_1_1Point2.html#a3bf8024da0811eb85f43b713ad678c2d", null ],
    [ "setY", "classkipr_1_1geometry_1_1Point2.html#ab483675a35b25868efe966ec72449a99", null ],
    [ "toCPoint2", "classkipr_1_1geometry_1_1Point2.html#a74687f56e9bbd34b15b56bcc6652a414", null ],
    [ "x", "classkipr_1_1geometry_1_1Point2.html#a26fb7f0535a9158827556b476cf5f042", null ],
    [ "y", "classkipr_1_1geometry_1_1Point2.html#aa079ac01c97b7fbb5a21f56e6a6963ec", null ]
];
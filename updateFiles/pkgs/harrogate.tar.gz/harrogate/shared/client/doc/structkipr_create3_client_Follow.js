var structkipr_create3_client_Follow =
[
    [ "Create3FollowLeft", "structkipr_create3_client_Follow.html#a46c17cd2d42572a5b00eebc23dc79507a7fc56270e7a70fa81a5935b72eacbe29", null ],
    [ "Create3FollowRight", "structkipr_create3_client_Follow.html#a46c17cd2d42572a5b00eebc23dc79507a9d5ed678fe57bcca610140957afab571", null ],
];
var dir_effe5fb0962c555eb19a7b337e375db8 =
[
    [ "kipr", "dir_959b925764743f6ac78edd10f8c01b05.html", "dir_959b925764743f6ac78edd10f8c01b05" ]
];
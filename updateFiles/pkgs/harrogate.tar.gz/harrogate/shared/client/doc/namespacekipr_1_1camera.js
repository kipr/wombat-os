var namespacekipr_1_1camera =
[
    [ "ConfigPath", "classkipr_1_1camera_1_1ConfigPath.html", null ],
    [ "Device", "classkipr_1_1camera_1_1Device.html", "classkipr_1_1camera_1_1Device" ],
    [ "Channel", "classkipr_1_1camera_1_1Channel.html", "classkipr_1_1camera_1_1Channel" ],
    [ "Image", "classkipr_1_1camera_1_1Image.html", "classkipr_1_1camera_1_1Image" ],
    [ "Object", "classkipr_1_1camera_1_1Object.html", "classkipr_1_1camera_1_1Object" ],
    [ "ObjectVector", "namespacekipr_1_1camera.html#ab5b03a717a191c7377854e2518658748", null ],
    [ "cDevice", "namespacekipr_1_1camera.html#a79c2a8408a3c0d3a1b5648426aea1583", null ]
];
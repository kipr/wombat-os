var namespacekipr_1_1create =
[
    [ "CreatePackets", "namespacekipr_1_1create_1_1CreatePackets.html", "namespacekipr_1_1create_1_1CreatePackets" ],
    [ "sensors", "namespacekipr_1_1create_1_1sensors.html", null ],
    [ "CreateScript", "classkipr_1_1create_1_1CreateScript.html", "classkipr_1_1create_1_1CreateScript" ],
    [ "CreateState", "structkipr_1_1create_1_1CreateState.html", "structkipr_1_1create_1_1CreateState" ],
    [ "Create", "classkipr_1_1create_1_1Create.html", "classkipr_1_1create_1_1Create" ]
];
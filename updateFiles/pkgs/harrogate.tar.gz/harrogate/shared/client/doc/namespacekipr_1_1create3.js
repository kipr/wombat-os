var namespacekipr_1_1create3 =
[
    [ "client", "namespacekipr_1_1create3_1_1client.html", "namespacekipr_1_1create3_1_1client" ],
    [ "Create3", "namespacekipr_1_1create_1_1Create3.html", "namespacekipr_1_1create_1_1Create3" ],

];
var classkipr_1_1magneto_1_1MagnetoY =
[
    [ "value", "classkipr_1_1magneto_1_1MagnetoY.html#a673412aa9cdb70ed5316ca228a18c6cb", null ]
];
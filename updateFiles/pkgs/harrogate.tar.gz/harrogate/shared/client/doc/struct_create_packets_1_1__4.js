var struct_create_packets_1_1__4 =
[
    [ "chargingSourcesAvailable", "struct_create_packets_1_1__4.html#aeab756c5d9d350440ffb29a58f8bbb5d", null ],
    [ "cliffFrontLeftSignal", "struct_create_packets_1_1__4.html#a02cffb8a2c423237164044618e2a9eb6", null ],
    [ "cliffFrontRightSignal", "struct_create_packets_1_1__4.html#a5e5e63220d3519e3c496180dbaf0811f", null ],
    [ "cliffLeftSignal", "struct_create_packets_1_1__4.html#a56aab6bb8d48fb6b892c310324cca385", null ],
    [ "cliffRightSignal", "struct_create_packets_1_1__4.html#a1a4679ea5378b21fb037a10b272a12a4", null ],
    [ "userAnalogInput", "struct_create_packets_1_1__4.html#a6d577f75c0977a26e56a1ef56f6a957e", null ],
    [ "userDigitalInputs", "struct_create_packets_1_1__4.html#af1771fad582599b5a9345d1076ede4ff", null ],
    [ "wallSignal", "struct_create_packets_1_1__4.html#afb74f9291bec30bd25cfc13c8af2c3c6", null ]
];
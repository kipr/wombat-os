var display_8h =
[
    [ "display_clear", "display_8h.html#aee07a233052bd0b8f6e461d21f380d4e", null ],
    [ "display_printf", "display_8h.html#abbf993d2dc1de781d106a1ca2c8c484d", null ]
];
var structkipr_create3_client_LedAnimationType =
[
    [ "Create3BlinkLights", "structkipr_create3_client_LedAnimationType.html#a46c17cd2d42572a5b00eebc23dc79507a7fc56270e7a70fa81a5935b72eacbe29", null ],
    [ "Create3SpinLights", "structkipr_create3_client_LedAnimationType.html#a46c17cd2d42572a5b00eebc23dc79507a9d5ed678fe57bcca610140957afab571", null ],
    [ "Create3InvalidType", "structkipr_create3_client_LedAnimationType.html#a46c17cd2d42572a5b00eebc23dc79507a0d61f8370cad1d412f80b84d143e1257", null ],
];
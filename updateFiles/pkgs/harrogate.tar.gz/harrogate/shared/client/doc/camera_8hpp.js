var camera_8hpp =
[
    [ "ConfigPath", "classkipr_1_1camera_1_1ConfigPath.html", null ],
    [ "Device", "classkipr_1_1camera_1_1Device.html", "classkipr_1_1camera_1_1Device" ],
    [ "CAMERA_CHANNEL_GROUP_PREFIX", "camera_8hpp.html#a69eefcdd87c0b0c907d39b31a35ff8e6", null ],
    [ "CAMERA_CHANNEL_TYPE_ARUCO_KEY", "camera_8hpp.html#adafcedd0de22c00ef31989aeee8a6de5", null ],
    [ "CAMERA_CHANNEL_TYPE_HSV_KEY", "camera_8hpp.html#a13fbdc843631bf347b80509790c98b62", null ],
    [ "CAMERA_CHANNEL_TYPE_KEY", "camera_8hpp.html#a4cf7189f2d6907d0ffd2e284389be779", null ],
    [ "CAMERA_CHANNEL_TYPE_QR_KEY", "camera_8hpp.html#a3316d068be31f34e512b0acbdc9c688d", null ],
    [ "CAMERA_GROUP", "camera_8hpp.html#a052eafbd228358c47934bf97e6da46f0", null ],
    [ "CAMERA_NUM_CHANNELS_KEY", "camera_8hpp.html#a6c79d4366eea9f99e4767cefec459bdd", null ],
    [ "cDevice", "camera_8hpp.html#a79c2a8408a3c0d3a1b5648426aea1583", null ]
];
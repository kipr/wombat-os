var class_console =
[
    [ "clear", "class_console.html#a37a8561cc9b3ae7367290fe1667ba0db", null ]
];
var classkipr_1_1compass_1_1Compass =
[
    [ "Compass", "classkipr_1_1compass_1_1Compass.html#aee578bb4186b6934d11790d1f8f02c61", null ],
    [ "~Compass", "classkipr_1_1compass_1_1Compass.html#ae5dffbd0a1095fcd61dbed3eddcecab2", null ]
];
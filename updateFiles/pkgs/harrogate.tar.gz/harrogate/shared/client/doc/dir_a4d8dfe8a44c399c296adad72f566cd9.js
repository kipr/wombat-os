var dir_a4d8dfe8a44c399c296adad72f566cd9 =
[
    [ "kipr", "dir_671bd19ce3ce27d652ded3bb772f9da6.html", "dir_671bd19ce3ce27d652ded3bb772f9da6" ]
];
var wait__for_8h =
[
    [ "wait_for_a_button", "wait__for_8h.html#ae05810376ef3be973a565af8b7470693", null ],
    [ "wait_for_a_button_clicked", "wait__for_8h.html#af413b9f424f6f55b45805aa161125605", null ],
    [ "wait_for_any_button", "wait__for_8h.html#ab1c1b0de9d8cbfd8a7574b367d57f9f1", null ],
    [ "wait_for_b_button", "wait__for_8h.html#ae196d362dcc42731add42961d3af9c36", null ],
    [ "wait_for_b_button_clicked", "wait__for_8h.html#ac1bc2051b8b966ab9e0d15a6dd6513db", null ],
    [ "wait_for_c_button", "wait__for_8h.html#a8385c7f8de3278ffc64481beba49ffbf", null ],
    [ "wait_for_c_button_clicked", "wait__for_8h.html#a868a70fc91aa446f8d719c6d13c5d9f2", null ],
    [ "wait_for_milliseconds", "wait__for_8h.html#a74acd89d9a666f725aaa1a476b0e365d", null ],
    [ "wait_for_side_button", "wait__for_8h.html#a94a83d05c1588cba3b2fa7b80e8f7ad0", null ],
    [ "wait_for_side_button_clicked", "wait__for_8h.html#a4df94b781ad03619d46d30dcbf08dd5a", null ],
    [ "wait_for_touch", "wait__for_8h.html#a368e329006021dadff3cc5a242fa3496", null ],
    [ "wait_for_x_button", "wait__for_8h.html#aee3cee1ad54ff82ed8953b7f4ce593a9", null ],
    [ "wait_for_x_button_clicked", "wait__for_8h.html#aa02cf2ac3023fcfb71641e45e770d17e", null ],
    [ "wait_for_y_button", "wait__for_8h.html#ab8c44ae16043d54ba32460e33137495c", null ],
    [ "wait_for_y_button_clicked", "wait__for_8h.html#abc3fd91fb30a4c67f83a8ed29685a843", null ],
    [ "wait_for_z_button", "wait__for_8h.html#a8b17289ed8940e950d6accf9347e6542", null ],
    [ "wait_for_z_button_clicked", "wait__for_8h.html#a6f2f765b38c4582e9580c3845993148b", null ]
];
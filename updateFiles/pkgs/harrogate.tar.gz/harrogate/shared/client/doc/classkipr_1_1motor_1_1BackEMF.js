var classkipr_1_1motor_1_1BackEMF =
[
    [ "BackEMF", "classkipr_1_1motor_1_1BackEMF.html#a58decb082f3349477f41d01907c70113", null ],
    [ "port", "classkipr_1_1motor_1_1BackEMF.html#aaaaab063495c6d24dc984eca92dc83c4", null ],
    [ "value", "classkipr_1_1motor_1_1BackEMF.html#abe55ef718fbcdf570020f981b0cc8dc8", null ]
];
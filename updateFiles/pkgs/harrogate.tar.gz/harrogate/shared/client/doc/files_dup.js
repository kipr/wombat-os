var files_dup =
[
    [ "module", "dir_a7b0466279106ea0b8f86f609f621680.html", "dir_a7b0466279106ea0b8f86f609f621680" ],
    [ "client", "dir_scX43EKttEUjWGU9MYxu5BODr2knM3wM.html", "dir_scX43EKttEUjWGU9MYxu5BODr2knM3wM" ],
    [ "pages", "dir_31a378c84b956866319ca9d9294f1959.html", "dir_31a378c84b956866319ca9d9294f1959" ]
];